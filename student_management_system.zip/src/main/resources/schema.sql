-- Database Setup
CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;

-- Students Table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    course VARCHAR(50) NOT NULL,
    gpa DOUBLE DEFAULT 0.0,
    attendance_rate DOUBLE DEFAULT 0.0
);

-- Sample Data
INSERT INTO students (name, email, course, gpa, attendance_rate) VALUES
('Alice Smith', 'alice@example.com', 'Computer Science', 3.8, 95.0),
('Bob Jones', 'bob@example.com', 'Data Science', 3.5, 91.2);
